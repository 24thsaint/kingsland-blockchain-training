const Key = require('./Key')
const key = new Key()
console.log(key)

const key2 = new Key('7e4670ae70c98d24f3662c172dc510a085578b9ccc717e6c2f4e547edd960a34')
console.log(key2)