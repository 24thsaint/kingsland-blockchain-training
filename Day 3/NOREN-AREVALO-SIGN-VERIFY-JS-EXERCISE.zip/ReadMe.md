# Install dependencies

> npm install

# Run program

> npm start