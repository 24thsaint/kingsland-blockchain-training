# Install dependencies

> npm install

# Run

> npm start