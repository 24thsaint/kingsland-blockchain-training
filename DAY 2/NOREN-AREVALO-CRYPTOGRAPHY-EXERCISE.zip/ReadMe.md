# To run the program

Requirements: NodeJS v8.11.1 or higher

Please make sure that you have installed the windows-build-tools so that node-gyp can function correctly

> npm install -g --production windows-build-tools

Install node-gyp for SCrypt to compile

> npm install -g node-gyp

---

Then install the project dependencies

> npm install

Every activity is categorized by folder and running ./FOLDER/test.js will run the program according to the requirements specific in the document.