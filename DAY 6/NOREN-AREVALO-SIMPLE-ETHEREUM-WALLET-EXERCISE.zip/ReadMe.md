# Install dependencies

> npm install

# Start the program

> npm start